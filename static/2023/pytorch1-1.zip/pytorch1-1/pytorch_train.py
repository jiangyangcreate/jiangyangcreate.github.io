import pandas
import matplotlib.pyplot
import glob
import numpy
import imageio
import torch
import torch.nn as nn
from torch.utils.data import Dataset

class Classifier(nn.Module):

    def __init__(self):
        # init Pytorch Parent class
        super().__init__()

        # Define the layers of a neural network
        self.model = nn.Sequential(
            nn.Linear(784, 200),
            nn.Sigmoid(),
            nn.Linear(200, 10),
            nn.Sigmoid()
        )
        # Create a loss function that uses the error function (or loss function) to update the connection weights of the network
        self.loss_function = nn.MSELoss()
        #Stochastic Gradient Descent，SGD，0.01。
        self.optimiser = torch.optim.SGD(self.parameters(), lr=0.1)
    def forward(self, inputs):
        return self.model(inputs)
    
    def train(self, inputs, targets):

        outputs = self.forward(inputs)

        loss = self.loss_function(outputs, targets)
        self.optimiser.zero_grad()
        loss.backward()
        self.optimiser.step()

        # Initialization counters and lists
        self.counter = 0
        self.progress = []

        self.counter += 1
        if (self.counter % 10 == 0):
            self.progress.append(loss.item())

        if (self.counter % 10000 == 0):
            print("counter = ", self.counter)

    def plot_progress(self):
        df = pandas.DataFrame(self.progress, columns=['loss'])
        df.plot(ylim=(0, 1.0), figsize=(16,8), alpha=0.1, marker='.',  grid=True, yticks=(0, 0.25, 0.5)) 

class MnistDataset(Dataset):

    def __init__(self, csv_file):
        self.data_df = pandas.read_csv(csv_file, header=None)

    def __len__(self):
        return len(self.data_df)

    def __getitem__(self, index):
        # Image Label
        label = self.data_df.iloc[index,0]
        target = torch.zeros((10))
        target[label] = 1.0 

        # Data on graph, normalized from 0-255 to 0-1
        image_values = torch.FloatTensor(self.data_df.iloc[index,1:].values)/ 255.0

        # Return image labels, image data, and targets
        return label, image_values, target
    def plot_image(self, index):
        data = self.data_df.iloc[index]
        # The first value in the variable data is the number represented by the row, assigned to label
        label = data[0]
        # The remaining 784 values can be visualized and displayed as images
        img = data[1: ].values.reshape(28, 28) 
        matplotlib.pyplot.title("label = " + str(label))
        matplotlib.pyplot.imshow(img, interpolation='none', cmap='Blues')
        matplotlib.pyplot.show()

# use 100 data will be very fast
#training_data_file = r'mnist_dataset\mnist_train_100.csv'

# use
training_data_file = r'mnist_dataset\mnist_train_100.csv'

mnist_dataset = MnistDataset(training_data_file)

# create network
C = Classifier()

epochs = 3

for i in range(epochs):
    print('training epoch', i + 1, "of", epochs)
    for label, image_data_tensor, target_tensor in mnist_dataset:
        C.train(image_data_tensor, target_tensor)

# our own image test data set
our_own_dataset = []

# load the png image data as test data set
for image_file_name in glob.glob('my_own_images/2828_my_own_?.png'):
    
    # use the filename to set the correct label
    label = int(image_file_name[-5:-4])
    
    # load image data from png files into an array
    print ("loading ... ", image_file_name)
    img_array = imageio.imread(image_file_name, as_gray=True)
    
    # reshape from 28x28 to list of 784 values, invert values
    img_data  = 255.0 - img_array.reshape(784)
    
    # then scale data to range from 0.01 to 1.0
    img_data = (img_data / 255.0 * 0.99) + 0.01
    print(numpy.min(img_data))
    print(numpy.max(img_data))
    
    # append label and image data  to test data set
    record = numpy.append(label,img_data)
    our_own_dataset.append(record)
    

for item in range(len(our_own_dataset)):

    # plot image
    matplotlib.pyplot.imshow(our_own_dataset[item][1:].reshape(28,28), cmap='Greys', interpolation='None')

    # correct answer is first value
    correct_label = our_own_dataset[item][0]
    # data is remaining values
    inputs = torch.Tensor(our_own_dataset[item][1:])
    # query the network
    outputs = C.forward(inputs)
    outputs = outputs.detach().numpy()
    print(outputs)
    # the index of the highest value corresponds to the label
    label = numpy.argmax(outputs)
    print("network says ", label)
    print("True is ", correct_label)